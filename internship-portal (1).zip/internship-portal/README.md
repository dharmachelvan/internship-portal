# Internship Portal

A beginner-friendly full-stack internship board built without a frontend framework.

## Features

- Semantic, responsive HTML/CSS/JavaScript
- Search by title, company, location, description, and skills
- Domain/category filtering
- Empty and API error states
- Accessible labels, focus states, keyboard-friendly controls
- Internship detail modal
- Secure application form with server-side validation
- REST CRUD API
- SQLite persistence
- Pagination
- Consistent JSON responses
- Helmet security headers
- Basic application duplicate protection
- API smoke tests
- Responsive mobile/tablet/desktop layout

## Tech stack

- HTML5
- CSS3
- Vanilla JavaScript
- Node.js
- Express
- SQLite via better-sqlite3

## Run locally

```bash
npm install
npm run seed
npm start
```

Open `http://localhost:3000`.

For development:

```bash
npm run dev
```

Run tests:

```bash
npm test
```

## API

### List internships

`GET /api/internships?page=1&limit=6&search=developer&domain=Engineering`

### Get one

`GET /api/internships/:id`

### Create

`POST /api/internships`

Example:

```json
{
  "title": "Frontend Developer Intern",
  "company": "Acme Labs",
  "location": "Remote",
  "domain": "Engineering",
  "type": "Internship",
  "duration": "3 months",
  "stipend": "₹15,000/month",
  "description": "Build accessible web experiences.",
  "skills": ["HTML", "CSS", "JavaScript"],
  "apply_url": "https://example.com/apply"
}
```

### Update

`PUT /api/internships/:id`

### Delete

`DELETE /api/internships/:id`

### Apply

`POST /api/applications`

Example:

```json
{
  "internship_id": 1,
  "name": "Asha Kumar",
  "email": "asha@example.com",
  "phone": "9876543210",
  "resume_url": "https://example.com/resume.pdf",
  "cover_note": "I would love to apply."
}
```

## Response format

Successful list responses:

```json
{
  "success": true,
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 6,
    "total": 0,
    "pages": 0
  }
}
```

Errors:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Please correct the highlighted fields.",
    "fields": {}
  }
}
```

## Database

SQLite is created automatically at `data/internships.db`.

Tables:

- `internships`
- `applications`

## Suggested submission

1. Create a public GitHub repository named `internship-portal`.
2. Push this project.
3. Deploy the Node app on a service that supports Node.js.
4. Add the deployed URL to this README.
5. Add screenshots to `screenshots/` for desktop, tablet, and mobile.
6. Submit the GitHub/deployed proof link requested by the task.

## Acceptance checklist

- [x] Semantic HTML
- [x] Reusable internship card rendering
- [x] Search
- [x] Domain filter
- [x] Empty state
- [x] Error state
- [x] Keyboard-friendly interaction
- [x] Form labels
- [x] Responsive layout
- [x] REST list/detail/create/update/delete
- [x] Validation
- [x] Pagination
- [x] SQLite persistence
- [x] Application form
- [x] Server-side validation
- [x] Basic API tests
