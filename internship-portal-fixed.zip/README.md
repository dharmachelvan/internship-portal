# Internship Board

A responsive full-stack internship discovery and application portal built for the Edvyro Full-Stack Development internship tasks (Task 02 – Task 05).

**Repository:** https://github.com/dharmachelvan/internship-portal

## Project Overview

The project demonstrates the complete progression required by the Edvyro capstone: a responsive vanilla-JavaScript internship board, a REST API with persistent storage, a secure application-submission flow, and production-readiness polish (testing, security, accessibility, deployment).

## Features

### Task 02 — Responsive Internship Board
- Semantic HTML5 structure (`header`, `main`, `section`, `article`, `form`, `footer`)
- Responsive mobile, tablet, and desktop layout — no frontend framework
- Vanilla JavaScript DOM rendering (reusable card renderer)
- Search by keyword, domain filtering, and pagination working together
- Loading, empty, and error states
- Skip link, labelled form controls, visible focus states, keyboard-friendly controls
- Internship details dialog and application dialog

### Task 03 — REST API and Persistent Data
- Node.js + Express REST API
- SQLite persistence via `better-sqlite3`, auto-created schema
- Seed data (8 sample internships) loaded automatically on first run
- Full CRUD for internships (`GET`, `POST`, `PUT`, `DELETE`)
- Search, domain filtering, and pagination via query params
- Consistent JSON response envelope and correct HTTP status codes (200/201/400/404/422/500)
- `GET /api/health` health check

### Task 04 — Secure Application Integration
- Frontend fetches internships from the REST API (no hardcoded data once loaded)
- `POST /api/applications` endpoint with persistent storage
- Client-side **and** server-side validation (name, email, phone, resume URL, cover note)
- Duplicate-application protection (unique constraint on internship + email)
- Helmet security headers, `x-powered-by` disabled
- Exact-origin CORS (configurable via `ALLOWED_ORIGIN`)
- In-memory rate limiting (general API + stricter limit on applications)
- Request body size limit (100kb)
- Parameterized SQL queries throughout
- `.env.example` provided, `.env` excluded via `.gitignore`

### Task 05 — Production-Ready Capstone
- Polished, responsive user journey end to end
- Automated API tests (Node's built-in test runner)
- Deployment configuration for both Vercel and Render
- Security, accessibility, and deployment documentation (this file + `DEPLOYMENT.md`)

## Tech Stack

- HTML5, CSS3, vanilla JavaScript (no frontend framework)
- Node.js 20+, Express 5
- SQLite via `better-sqlite3`
- Helmet
- Node.js built-in test runner (`node --test`)

## Project Structure

```text
internship-portal/
├── api/
│   └── index.js          # Vercel serverless entry point (re-exports server.js)
├── index.html             # Semantic markup + dialogs
├── style.css              # Responsive styling
├── script.js               # DOM rendering, search/filter, form handling
├── server.js               # Express app, routes, security middleware
├── db.js                   # SQLite connection + schema bootstrap
├── schema.sql               # Table definitions
├── seed.js                  # Seed data (runs automatically if DB is empty)
├── validation.js             # Shared server-side validation rules
├── api.test.js                # Automated API tests
├── package.json
├── vercel.json
├── render.yaml
├── .env.example
├── .gitignore
├── DEPLOYMENT.md
└── PROJECT_SUMMARY.md
```

## Frontend Setup

The frontend is plain HTML/CSS/JS with no build step. It is served directly by the Express server (`server.js` serves the repository root as static files), so once the backend is running the frontend is available at the same URL — no separate setup is required.

If you only want to preview the static markup without the API, you can open `index.html` directly in a browser, but search/filter/apply will not work without the backend running (the board fetches live data from `/api/*`).

## Backend Setup

### Requirements
- Node.js 20 or newer
- npm

### Install dependencies

```bash
npm install
```

This installs `express`, `helmet`, and `better-sqlite3`.

## Database Setup

The database is SQLite and requires no separate server. On startup, `db.js` creates the database file and applies `schema.sql` automatically (tables: `internships`, `applications`).

Seed data (8 sample internships) is inserted automatically the first time the database is empty. You can also run it manually:

```bash
npm run seed
```

Local database file location: `./data/internships.db` (ignored by Git). On Vercel, the path is switched to `/tmp` because serverless filesystems are read-only outside `/tmp` — see the Deployment section for the production-persistence note.

## Environment Variables

Copy `.env.example` to `.env` and set values as needed:

```text
ALLOWED_ORIGIN=
PORT=3000
```

| Variable | Required | Purpose |
|---|---|---|
| `PORT` | No (defaults to 3000) | Port the Express server listens on |
| `ALLOWED_ORIGIN` | No | Exact origin to allow via CORS if the frontend is ever hosted separately from the API. Leave blank for same-origin deployments (the default setup). |

`.env` is excluded via `.gitignore` and must never be committed.

## Running Locally

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

Development mode with auto-restart on file changes:

```bash
npm run dev
```

## API Endpoints

Base URL: `/api`

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/domains` | Distinct list of domains for the filter dropdown |
| GET | `/api/internships` | List internships (supports `page`, `limit`, `search`, `domain`) |
| GET | `/api/internships/:id` | Get one internship |
| POST | `/api/internships` | Create an internship |
| PUT | `/api/internships/:id` | Update an internship |
| DELETE | `/api/internships/:id` | Delete an internship |
| POST | `/api/applications` | Submit an application |

## API Examples

### Health check
```http
GET /api/health
```

### List with pagination
```http
GET /api/internships?page=1&limit=10
```

### Search
```http
GET /api/internships?search=python
```

### Filter by domain
```http
GET /api/internships?domain=Engineering
```

### Search and filter combined
```http
GET /api/internships?page=1&limit=6&search=remote&domain=Engineering
```

### Create an internship
```http
POST /api/internships
Content-Type: application/json

{
  "title": "Frontend Developer Intern",
  "company": "Example Labs",
  "location": "Remote",
  "domain": "Engineering",
  "type": "Internship",
  "duration": "3 months",
  "stipend": "₹15,000/month",
  "description": "Build responsive web interfaces.",
  "skills": ["HTML", "CSS", "JavaScript"],
  "apply_url": "https://example.com/apply"
}
```

### Update / Delete
```http
PUT /api/internships/:id      (same body shape as create)
DELETE /api/internships/:id
```

### Submit an application
```http
POST /api/applications
Content-Type: application/json

{
  "internship_id": 1,
  "name": "Example Applicant",
  "email": "applicant@example.com",
  "phone": "+91 9876543210",
  "resume_url": "https://example.com/resume.pdf",
  "cover_note": "I am interested in this internship because I enjoy building web applications."
}
```

### Response format

Success:
```json
{ "success": true, "data": {} }
```

Error:
```json
{
  "success": false,
  "error": { "code": "VALIDATION_ERROR", "message": "Please correct the highlighted fields.", "fields": {} }
}
```

## Testing

Run the automated API test suite:

```bash
npm test
```

Covers: health endpoint, pagination/filtering, internship details, validation errors, full CRUD (create/update/delete), application submission, duplicate-application rejection, application validation, and unknown-route handling.

> Note: `npm test` requires `npm install` to have completed successfully first (it needs `better-sqlite3` compiled for your platform).

## Security

Implemented:
- Helmet security headers; `x-powered-by` disabled
- Exact-origin CORS (`ALLOWED_ORIGIN`)
- API-wide rate limiting, plus a stricter limit on `/api/applications`
- Parameterized SQLite queries everywhere (no string-concatenated SQL)
- Request body size limit (100kb)
- Server-side validation on every write endpoint, mirrored by client-side validation
- Duplicate-application protection via a unique DB constraint
- Generic, safe error messages returned to clients (no stack traces)
- `.env` excluded from Git; secrets are never hardcoded

Never commit: `.env`, database files, API keys, or credentials of any kind.

## Accessibility

Implemented:
- Semantic HTML landmarks
- Skip-to-content link
- Labelled form controls throughout
- `aria-live` regions for result counts and loading/empty/error states
- `role="alert"` on error and validation messages
- Visible keyboard focus states on all interactive elements
- Fully keyboard-operable buttons, filters, and dialogs (native `<dialog>` supports Esc-to-close)
- `aria-invalid` and field-level error text tied to inputs via `aria-describedby`
- Touch-friendly control sizing on small screens

## Deployment

### Vercel

The repository includes `api/index.js` (re-exports the Express app) and `vercel.json` (routes `/api/*` to it and everything else to the static frontend).

1. Import the GitHub repository into Vercel.
2. Keep the root directory as the repository root; no build command is required.
3. Deploy.
4. Verify `/api/health`, then the board and application flow.

**Persistence note:** Vercel serverless functions have a read-only filesystem outside `/tmp`. `db.js` detects `process.env.VERCEL` and stores the SQLite file in `/tmp`, which lets the demo run but is **not durable** — data can be lost when the function instance is recycled. For real production persistence, migrate to PostgreSQL/Supabase and use `DATABASE_URL`.

### Render

The repository includes `render.yaml`:

```text
Build command: npm install
Start command: npm start
Health check:  /api/health
```

Render's standard web service has a persistent filesystem, so SQLite persists correctly there. See `DEPLOYMENT.md` for the full step-by-step guide.

### Deployment status

This chat environment has no outbound network access, so no deployment or live-URL check could be performed as part of this work. Before submitting, deploy (or re-verify an existing deployment) and confirm `/api/health` responds, then update this section with the live URL.

## Screenshots

Add these before final submission:

```text
screenshots/
├── desktop.png
├── tablet.png
└── mobile.png
```

Recommended: desktop board, tablet layout, mobile layout, application success state, and a test-run screenshot if the evaluator wants proof of `npm test`.

## Future Improvements

- PostgreSQL/Supabase for durable production persistence
- Authentication and role-based administration
- Admin dashboard for managing internships
- Resume file upload storage
- Email notifications on application submission
- Saved/bookmarked internships
- Advanced sorting (stipend, duration, newest)

## Submission Checklist

- [x] Responsive internship board (mobile/tablet/desktop)
- [x] Semantic HTML, no frontend framework
- [x] Search and domain filtering (combined)
- [x] Pagination
- [x] Loading, empty, and error states
- [x] REST API with full CRUD
- [x] Persistent SQLite schema + seed data
- [x] Server-side and client-side validation
- [x] Application endpoint with duplicate protection
- [x] Security headers, CORS, rate limiting, parameterized queries
- [x] Automated API tests
- [x] Deployment configuration (Vercel + Render)
- [x] Documentation (this file + DEPLOYMENT.md)
- [ ] Add final screenshots
- [ ] Run `npm install && npm test` locally to confirm a green test run
- [ ] Verify the live deployed URL immediately before submission
